#include <bits/stdc++.h>
using namespace std;

class SymbolInfo {
    string name, type;

   public:
    SymbolInfo(string name, string type) {
        this->name = name;
        this->type = type;
    }
    void setValue(string name, string type) {
        this->name = name, this->type = type;
    }
    string getName() { return name; }
    string getType() { return type; }
    void display() { cout << "<" << type << ", " << name << ">"; }
};

class SymbolTable {
    vector<SymbolInfo> table[17];

   public:
    int getHashIndex(string s) {
        int asciiCnt = 0;
        for (char i : s)
            asciiCnt += i;
        return (asciiCnt * 12) % 17;
    }
    pair<int, int> lookup(string name, string type = "") {
        int id = getHashIndex(name);
        for (int j = 0; j < (int)table[id].size(); j++) {
            if (table[id][j].getName() == name and table[id][j].getType() == type){
                return {id, j};
            }
        }
        return {-1, -1};
    }
    void print() {
        for (int i = 0; i < 17; i++) {
            // if (table[i].size() == 0) continue;
            cout << i << "--> ";
            for (int j = 0; j < (int)table[i].size(); j++) {
                table[i][j].display();
                cout << " ";
            }
            cout << endl;
        }
    }
    void insert(SymbolInfo s) {
        pair<int, int> temp = lookup(s.getName(), s.getType());
        if (temp.first != -1 and temp.second != -1) {
            cout << s.getName() << " variable already exists"
                 << endl;
            return;
        }
        int id = getHashIndex(s.getName());
        int idofid = table[id].size();
        table[id].push_back(s);
        print();
    }
    void DELETE(string name) {
        pair<int, int> temp = lookup(name);
        if (temp.first != -1 and temp.second != -1) {
            cout << "Deleted from " << temp.first << " " << temp.second << endl;
            table[temp.first].erase(table[temp.first].begin() + temp.second);
        }
        else
            cout << "Doesn't Exists" << endl;
    }
};

string toUpper(string s){
    for (int i = 0; i < s.size(); i++)
        s[i] = toupper(s[i]);
    return s;
}

// int main() {
//     freopen("input.txt", "r", stdin);
//     freopen("output.txt", "w", stdout);
//     SymbolTable T;
//     char ty;
//     while (cin >> ty) {
//         if (ty == 'I') {
//             string name, type;
//             cin >> name >> type;
//             SymbolInfo S(name, type);
//             T.insert(S);
//         }
//         else if (ty == 'P') {
//             T.print();
//         }
//         else if (ty == 'L') {
//             string s;
//             cin >> s;
//             pair<int, int> idx = T.lookup(s);
//             if (idx.first == -1 and idx.second == -1)
//                 cout << "Not Found" << endl;
//             else
//                 cout << "Found at " << idx.first << " " << idx.second <<
//                 endl;
//         }
//         else if (ty == 'D') {
//             string s;
//             cin >> s;
//             T.DELETE(s);
//         }
//     }
//     return 0;
// }